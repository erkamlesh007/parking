build - mvn clean install

run- Run as Spring Boot App

url-http://localhost:9099/parking-billing/fromTime/0/toTime/2