package com.nm.parkinglot;

public interface IBillingService {

	int getBillingAmount(int rate);

}
