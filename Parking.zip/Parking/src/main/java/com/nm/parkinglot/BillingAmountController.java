package com.nm.parkinglot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillingAmountController {

	@Autowired
	BillingService billingService;

	@GetMapping("/parking-billing/fromTime/{from}/toTime/{to}")
	public ParkingBean convertCurrency(@PathVariable int from, @PathVariable int to) {

		int hrs = to - from; // TODO time to hour calculation
		int amount = billingService.getBillingAmount(hrs);

		return new ParkingBean(from, to, amount);

	}

}
