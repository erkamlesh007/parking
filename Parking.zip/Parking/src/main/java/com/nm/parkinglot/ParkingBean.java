package com.nm.parkinglot;

import java.io.Serializable;

public class ParkingBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int fromTime;

	private int toTime;

	private int billingAmount;

	public int getFromTime() {
		return fromTime;
	}

	public void setFromTime(int fromTime) {
		this.fromTime = fromTime;
	}

	public int getToTime() {
		return toTime;
	}

	public void setToTime(int toTime) {
		this.toTime = toTime;
	}

	public int getBillingAmount() {
		return billingAmount;
	}

	public void setBillingAmount(int billingAmount) {
		this.billingAmount = billingAmount;
	}

	public ParkingBean(int fromTime, int toTime, int billingAmount) {
		super();
		this.fromTime = fromTime;
		this.toTime = toTime;
		this.billingAmount = billingAmount;
	}

}
