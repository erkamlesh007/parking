package com.nm.parkinglot;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class BillingService implements IBillingService {

	@Override
	public int getBillingAmount(int hrs) {

		Map<Integer, Integer> charges = new HashMap<>();
		charges.put(2, 5);
		charges.put(5, 8);
		charges.put(10, 12);
		charges.put(15, 18);
		charges.put(24, 25);
		int sumCharge = 0;

		boolean isWeekend = isWeekend();
		// Decide its week day or weekend
		if (hrs <= 2)
			sumCharge = charges.get(2);
		else if (hrs <= 5)
			sumCharge = charges.get(5);
		else if (hrs <= 10)
			sumCharge = charges.get(10);
		else if (hrs <= 15)
			sumCharge = charges.get(15);
		else if (hrs <= 24)
			sumCharge = charges.get(24);
		if (isWeekend) {
			sumCharge = sumCharge + 3;
		}

		return sumCharge;
	}

	private boolean isWeekend() {
		boolean isWeekend = false;
		LocalDate date = LocalDate.now();
		DayOfWeek day = DayOfWeek.of(date.get(ChronoField.DAY_OF_WEEK));
		switch (day) {
		case SATURDAY:
			isWeekend = true;
		case SUNDAY:
			isWeekend = true;
		default:
			isWeekend = false;
			return isWeekend;
		}

	}
}
